//
//  ViewController.swift
//  List of Subjects
//
//  Created by Parmar Parth on 18/07/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

